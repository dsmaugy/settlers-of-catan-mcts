# settlers-of-catan-mcts
Implementing an agent to play a simplified version of Settlers of Catan using parallelized Monte Carlo Tree Search
